"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importStar(require("mongoose"));
const crypto_1 = __importDefault(require("crypto"));
// Define the cells dimensions
const ROWS = 5;
const COLS = 5;
const FREE_CELL = 'Free';
// Create the Cartella Schema
const CartellaSchema = new mongoose_1.Schema({
    cartellaNumber: {
        type: Number,
        required: true,
    },
    cells: {
        type: [[String]],
        required: true,
        validate: {
            validator: function (cells) {
                // Ensure it's a 5x5 grid
                if (cells.length !== ROWS)
                    return false;
                for (let row of cells) {
                    if (row.length !== COLS)
                        return false;
                }
                // Ensure the center cell is 'Free'
                return cells[2][2] === FREE_CELL;
            },
            message: `Cells must be a ${ROWS}x${COLS} grid with the center cell as '${FREE_CELL}'.`,
        },
    },
    partnershipId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Partnership',
        required: true,
    },
    branchName: {
        type: String,
        required: true,
    },
    cellsHash: {
        type: String,
        required: false, // Set this as optional because the middleware will populate it before saving
    },
}, {
    timestamps: true,
});
// Pre-save middleware to generate the cellsHash
CartellaSchema.pre('save', function (next) {
    console.log('Pre-save middleware triggered'); // Debugging output
    // Ensure the center cell is 'Free'
    if (this.cells[2][2] !== FREE_CELL) {
        this.cells[2][2] = FREE_CELL;
    }
    // Convert the cells array to string and generate a hash
    const cellsString = JSON.stringify(this.cells);
    // console.log('Cells string:', cellsString);  // Debugging output
    this.cellsHash = crypto_1.default.createHash('sha256').update(cellsString).digest('hex');
    // console.log('Generated cellsHash:', this.cellsHash);  // Debugging output
    next();
});
// Export the Cartella model
exports.default = mongoose_1.default.model('Cartella', CartellaSchema);
