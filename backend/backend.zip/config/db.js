"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importDefault(require("mongoose"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const { MONGODB } = process.env;
const ConnectToDB = () => {
    if (!MONGODB) {
        throw new Error('Mongodb secret key not found in .env file!');
    }
    // connect to mongodb
    mongoose_1.default.connect(MONGODB)
        .then(() => {
        console.log("Successfully connected to database");
    })
        .catch((error) => {
        console.log("database connection failed..");
        console.error(error);
        process.exit(1);
    });
};
exports.default = ConnectToDB;
