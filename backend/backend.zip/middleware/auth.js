"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorize_super_admin = exports.authorize_partnership = exports.authorize_caller = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
// jwt secret key
const JWT_Secret = process.env.JWT_KEY;
if (!JWT_Secret) {
    throw new Error('JWT key not found in .env file!');
}
// Authorize Caller
const authorize_caller = (req, res, next) => {
    const token = req.headers.authorization;
    if (!token) {
        return res.status(401).json({ message: 'No token, authorization denied' });
    }
    try {
        const decoded = jsonwebtoken_1.default.verify(token, JWT_Secret);
        if (decoded.role !== 'caller') {
            return res.status(401).json({ message: 'Invalid user token' });
        }
        req.user = decoded.userId;
        next();
    }
    catch (error) {
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.authorize_caller = authorize_caller;
// Authorize Partnership
const authorize_partnership = (req, res, next) => {
    const token = req.headers.authorization;
    if (!token) {
        return res.status(401).json({ message: 'No token, authorization denied' });
    }
    try {
        const decoded = jsonwebtoken_1.default.verify(token, JWT_Secret);
        if (decoded.role !== 'partnership') {
            return res.status(401).json({ message: 'Invalid user token' });
        }
        req.user = decoded.userId;
        next();
    }
    catch (error) {
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.authorize_partnership = authorize_partnership;
// Authorize Super Admin
const authorize_super_admin = (req, res, next) => {
    const token = req.headers.authorization;
    console.log(token);
    if (!token) {
        return res.status(401).json({ message: 'No token, authorization denied' });
    }
    try {
        const decoded = jsonwebtoken_1.default.verify(token, JWT_Secret);
        if (decoded.role !== 'super-admin') {
            return res.status(401).json({ message: 'Invalid admin token' });
        }
        next();
    }
    catch (error) {
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.authorize_super_admin = authorize_super_admin;
